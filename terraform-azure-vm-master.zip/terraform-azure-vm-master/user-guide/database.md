||||
|:--|:--|:--
|[Module Readme](../README.md)|[Module User Guide](../)|[Get Support](https://confluence.axa.com/confluence/x/L49iDw)|
##
## <font color="red"><b>Adding database to your Virtual Machine</b></font>

---
####
> NOTE: variable axavmrole needs to be set to sql, oracle, db2 and to add customizations variable custom_tags is required for puppet.
#### All custom configuration articles https://confluence.axa.com/confluence/x/5d_tDg

## Oracle Provisioning
https://confluence.axa.com/confluence/x/-ogqEQ
## SQL Provisioning
https://confluence.axa.com/confluence/x/EC5AEQ
## DB2 Provisioning
https://confluence.axa.com/confluence/x/U9FlEQ

