# Changelog
All notable changes to this module will be documented in this file
```
   _____                               
  /  _  \ __________ _________   ____  
 /  /_\  \\___   /  |  \_  __ \_/ __ \ 
/    |    \/    /|  |  /|  | \/\  ___/ 
\____|__  /_____ \____/ |__|    \___  >
        \/      \/                  \/ 

```
### [version:1.0.0](https://github.axa.com/ago-sharedtferegistry/terraform-azure-vm/tree/1.0.0) - (2022-12-19)
##### ADDED :tada:
- Concept is this of any use
##### UPDATED :+
##### FIXED :metal:
##### REMOVED :tada: